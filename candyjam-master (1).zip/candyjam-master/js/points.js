
/* POINTS */

MainGame.points = {
	  turret1: 800
	, turret2: 1500
	, firstaid: 500
	, hammer: 650
	, kill_corn: 70  //corn
	, kill_cane: 80 //gumball
	, kill_bear: 50 //mint
};